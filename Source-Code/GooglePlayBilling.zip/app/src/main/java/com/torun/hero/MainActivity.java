package com.torun.hero;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryProductDetailsResult;
import com.android.billingclient.api.QueryPurchasesParams;
import com.android.billingclient.api.UnfetchedProduct;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    // ============================================================
    // PRODUCT IDS - must match Play Console exactly (and be Active)
    // ============================================================
    private static final String SUB_PRODUCT = "pro_sub"; // Subscription Product ID
    private static final String LIFETIME    = "pro_lifetime"; //on time purchase id

    // Base plan IDs inside pro_sub
    private static final String PLAN_1_MONTH = "pro-1month"; // base id
    private static final String PLAN_3_MONTH = "pros-3month"; // base id
    private static final String PLAN_6_MONTH = "pro-6month"; // base id
    private static final String PLAN_1_YEAR  = "pro-1year"; // base id

    // UI keys (also used as map keys) for each card
    private static final String UI_1_MONTH = "ui_1month";
    private static final String UI_3_MONTH = "ui_3month";
    private static final String UI_6_MONTH = "ui_6month";
    private static final String UI_1_YEAR  = "ui_1year";
    private static final String UI_LIFETIME = "ui_lifetime";

    // Map: UI key -> base plan ID (null for lifetime)
    private static final Map<String, String> UI_TO_BASEPLAN = new HashMap<>();
    static {
        UI_TO_BASEPLAN.put(UI_1_MONTH, PLAN_1_MONTH);
        UI_TO_BASEPLAN.put(UI_3_MONTH, PLAN_3_MONTH);
        UI_TO_BASEPLAN.put(UI_6_MONTH, PLAN_6_MONTH);
        UI_TO_BASEPLAN.put(UI_1_YEAR,  PLAN_1_YEAR);
        UI_TO_BASEPLAN.put(UI_LIFETIME, null);
    }

    // ============================================================
    // PRO STATE (SharedPreferences "amar_t")
    // ============================================================
    private static final String PREFS = "amar_t";
    private static final String KEY_LIFETIME = "pro_lifetime";
    private static final String KEY_SUB = "pro_sub";
    private static final String KEY_VERIFIED = "pro_verified_ms";
    private static final long OFFLINE_GRACE_MS = 7L * 24 * 60 * 60 * 1000;

    public static boolean isPro(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        if (sp.getBoolean(KEY_LIFETIME, false)) return true;
        if (sp.getBoolean(KEY_SUB, false)) {
            long last = sp.getLong(KEY_VERIFIED, 0L);
            return (System.currentTimeMillis() - last) < OFFLINE_GRACE_MS;
        }
        return false;
    }

    // ============================================================
    // RECONNECT CONFIG
    // ============================================================
    private static final long RECONNECT_START_DELAY_MS = 1000L;
    private static final long RECONNECT_MAX_DELAY_MS = 32000L;
    private static final int MAX_SETUP_RETRIES = 6;

    // ============================================================
    // UI
    // ============================================================
    private TextView proStatusText;
    private TextView statusText;

    // UI key -> button / price label
    private final Map<String, Button> purchaseButtons = new HashMap<>();
    private final Map<String, TextView> priceLabels = new HashMap<>();

    // ============================================================
    // BILLING
    // ============================================================
    private BillingClient billingClient;

    // productId -> ProductDetails
    private final Map<String, ProductDetails> productDetailsMap = new HashMap<>();
    // productId -> offerToken (base plan offer token)
    private final Map<String, String> offerTokens = new HashMap<>();

    private boolean isConnecting = false;
    private boolean isQueryingProducts = false;
    private boolean retryScheduled = false;
    private int setupRetryCount = 0;

    private long reconnectDelayMs = RECONNECT_START_DELAY_MS;
    private final Runnable reconnectRunnable = new Runnable() {
        @Override
        public void run() {
            retryScheduled = false;
            connectBilling();
        }
    };

    private final List<Runnable> pendingServiceRequests = new ArrayList<>();

    private static final long LAUNCH_LOCK_TIMEOUT_MS = 30000L;
    private static final long LAUNCH_COOLDOWN_MS = 5000L;
    private boolean isLaunchingFlow = false;
    private long lastLaunchStartMs = 0L;
    private long launchLockTimeMs = 0L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private SharedPreferences amar_t;

    // ============================================================
    // ON CREATE
    // ============================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        amar_t = getSharedPreferences(PREFS, MODE_PRIVATE);

        setContentView(R.layout.main);
        bindViews();
        refreshProUi();

        setupBillingClient();
    }

    // ================================================================
    // UI (layout is in res/layout/activity_shop1.xml)
    // ================================================================

    private void bindViews() {
        proStatusText = findViewById(R.id.proStatusText);
        statusText    = findViewById(R.id.statusText);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.manageButton).setOnClickListener(v -> openManageSubscription());

        bindCard(UI_1_MONTH,  R.id.price1Month,  R.id.buy1Month);
        bindCard(UI_3_MONTH,  R.id.price3Month,  R.id.buy3Month);
        bindCard(UI_6_MONTH,  R.id.price6Month,  R.id.buy6Month);
        bindCard(UI_1_YEAR,   R.id.price1Year,   R.id.buy1Year);
        bindCard(UI_LIFETIME, R.id.priceLifetime, R.id.buyLifetime);
    }

    private void bindCard(final String uiKey, int priceId, int buttonId) {
        priceLabels.put(uiKey, (TextView) findViewById(priceId));

        Button buyButton = findViewById(buttonId);
        buyButton.setOnClickListener(v -> launchPurchase(uiKey));
        purchaseButtons.put(uiKey, buyButton);
    }

    private void refreshProUi() {
        if (proStatusText == null) return;
        if (amar_t.getBoolean(KEY_LIFETIME, false)) {
            proStatusText.setText("Lifetime Pro \u2705");
        } else if (isPro(this)) {
            proStatusText.setText("Pro (Subscribed) \u2705");
        } else {
            proStatusText.setText("Free");
        }
    }

    // ================================================================
    // MANAGE SUBSCRIPTION
    // ================================================================

    private void openManageSubscription() {
        try {
            Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package="
                    + getPackageName());
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            toast("Could not open Google Play subscriptions.");
        }
    }

    // ================================================================
    // BILLING CLIENT
    // ================================================================

    private void setupBillingClient() {

        billingClient = BillingClient.newBuilder(this)
                .setListener(purchasesUpdatedListener)
                .enablePendingPurchases(
                        PendingPurchasesParams.newBuilder()
                                .enableOneTimeProducts()
                                .build()
                )
                .build();

        connectBilling();
    }

    private void connectBilling() {

        mainHandler.removeCallbacks(reconnectRunnable);
        retryScheduled = false;

        if (billingClient == null) return;

        if (billingClient.isReady()) {
            reconnectDelayMs = RECONNECT_START_DELAY_MS;
            flushPendingServiceRequests();
            return;
        }

        if (isConnecting) return;
        isConnecting = true;

        billingClient.startConnection(new BillingClientStateListener() {

            @Override
            public void onBillingSetupFinished(@NonNull BillingResult result) {
                isConnecting = false;

                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    reconnectDelayMs = RECONNECT_START_DELAY_MS;
                    setupRetryCount = 0;
                    setStatus(null);
                    flushPendingServiceRequests();
                    queryRealProductPrices();
                    restorePastPurchases();
                } else {
                    handleSetupFailure(result.getResponseCode(), result.getDebugMessage());
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                isConnecting = false;
                disablePurchaseButtons();
                scheduleReconnectIfTransient();
            }
        });
    }

    private void handleSetupFailure(int code, String debugMessage) {

        disablePurchaseButtons();

        boolean transientError =
                code == BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE
                        || code == BillingClient.BillingResponseCode.SERVICE_DISCONNECTED
                        || code == BillingClient.BillingResponseCode.NETWORK_ERROR
                        || code == BillingClient.BillingResponseCode.ERROR;

        if (transientError) {
            scheduleReconnectIfTransient();
            return;
        }

        String hint;
        if (code == BillingClient.BillingResponseCode.DEVELOPER_ERROR) {
            hint = "Billing error 5 (DEVELOPER_ERROR). Check: 1) BILLING permission in manifest, "
                    + "2) app installed from Google Play testing track (not a sideloaded APK), "
                    + "3) package name and signing key match Play Console, "
                    + "4) pro_sub base plans and pro_lifetime are Active.";
        } else if (code == BillingClient.BillingResponseCode.BILLING_UNAVAILABLE) {
            hint = "Billing unavailable (3). Update Google Play Store and sign in with a Google account.";
        } else if (code == BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED) {
            hint = "This device does not support this billing feature (-2).";
        } else {
            hint = "Billing setup failed (code " + code + ").";
        }

        if (debugMessage != null && !debugMessage.isEmpty()) {
            hint = hint + "\nDetails: " + debugMessage;
        }

        setStatus(hint);
    }

    private void scheduleReconnectIfTransient() {

        if (retryScheduled) return;

        if (setupRetryCount >= MAX_SETUP_RETRIES) {
            setStatus("Could not reach Google Play. Please check your connection and reopen this screen.");
            return;
        }

        setupRetryCount++;
        retryScheduled = true;

        mainHandler.removeCallbacks(reconnectRunnable);
        mainHandler.postDelayed(reconnectRunnable, reconnectDelayMs);
        reconnectDelayMs = Math.min(reconnectDelayMs * 2, RECONNECT_MAX_DELAY_MS);
    }

    private void executeServiceRequest(Runnable request) {
        if (billingClient != null && billingClient.isReady()) {
            request.run();
        } else {
            pendingServiceRequests.add(request);
            connectBilling();
        }
    }

    private void flushPendingServiceRequests() {
        if (pendingServiceRequests.isEmpty()) return;
        List<Runnable> toRun = new ArrayList<>(pendingServiceRequests);
        pendingServiceRequests.clear();
        for (Runnable r : toRun) {
            r.run();
        }
    }

    // ================================================================
    // QUERY PRODUCT DETAILS / PRICES (SUBS + INAPP)
    // ================================================================

    private int pendingQueries = 0;

    private void queryRealProductPrices() {
        executeServiceRequest(this::doQueryRealProductPrices);
    }

    private void doQueryRealProductPrices() {

        if (billingClient == null || !billingClient.isReady()) return;
        if (isQueryingProducts) return;
        isQueryingProducts = true;
        pendingQueries = 2;

        // Only ONE subscription product ID (pro_sub) which contains 4 base plans
        queryByType(BillingClient.ProductType.SUBS, new String[]{SUB_PRODUCT});
        queryByType(BillingClient.ProductType.INAPP, new String[]{LIFETIME});
    }

    private void queryByType(final String type, final String[] ids) {

        List<QueryProductDetailsParams.Product> products = new ArrayList<>();
        for (String productId : ids) {
            products.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(productId)
                    .setProductType(type)
                    .build());
        }

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(products)
                .build();

        billingClient.queryProductDetailsAsync(params, new ProductDetailsResponseListener() {

            @Override
            public void onProductDetailsResponse(
                    @NonNull BillingResult result,
                    @NonNull QueryProductDetailsResult response
            ) {
                pendingQueries--;
                if (pendingQueries <= 0) isQueryingProducts = false;

                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    if (BillingClient.ProductType.SUBS.equals(type)) {
                        markAllSubscriptionCardsUnavailable();
                    } else {
                        markCardUnavailable(UI_LIFETIME);
                    }
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.DEVELOPER_ERROR) {
                        handleSetupFailure(result.getResponseCode(), result.getDebugMessage());
                    }
                    return;
                }

                final List<ProductDetails> detailsList = response.getProductDetailsList();
                final List<UnfetchedProduct> unfetched = response.getUnfetchedProductList();

                mainHandler.post(() -> {

                    if (detailsList != null) {
                        for (ProductDetails details : detailsList) {
                            updateProductDetails(details);
                        }
                    }

                    // If the subscription product itself was not returned -> all sub cards unavailable
                    boolean gotSubProduct = false;
                    if (detailsList != null) {
                        for (ProductDetails d : detailsList) {
                            if (SUB_PRODUCT.equals(d.getProductId())) {
                                gotSubProduct = true;
                                break;
                            }
                        }
                    }
                    if (BillingClient.ProductType.SUBS.equals(type) && !gotSubProduct) {
                        markAllSubscriptionCardsUnavailable();
                    }

                    if (unfetched != null) {
                        for (UnfetchedProduct item : unfetched) {
                            if (SUB_PRODUCT.equals(item.getProductId())
                                    && BillingClient.ProductType.SUBS.equals(type)) {
                                markAllSubscriptionCardsUnavailable();
                            } else if (LIFETIME.equals(item.getProductId())) {
                                markCardUnavailable(UI_LIFETIME);
                            }
                        }
                    }
                });
            }
        });
    }

    private void markAllSubscriptionCardsUnavailable() {
        markCardUnavailable(UI_1_MONTH);
        markCardUnavailable(UI_3_MONTH);
        markCardUnavailable(UI_6_MONTH);
        markCardUnavailable(UI_1_YEAR);
    }

    private void markCardUnavailable(final String uiKey) {
        mainHandler.post(() -> {
            TextView priceLabel = priceLabels.get(uiKey);
            Button buyButton = purchaseButtons.get(uiKey);

            if (priceLabel != null) priceLabel.setText("Not available");
            if (buyButton != null) {
                buyButton.setEnabled(false);
                buyButton.setAlpha(0.5f);
            }
        });
    }

    // ================================================================
    // MAP ProductDetails -> UI CARDS
    // ================================================================

    private void updateProductDetails(ProductDetails details) {

        if (details == null) return;

        String productId = details.getProductId();

        if (BillingClient.ProductType.SUBS.equals(details.getProductType())) {

            // Only pro_sub is expected
            if (!SUB_PRODUCT.equals(productId)) return;

            List<ProductDetails.SubscriptionOfferDetails> offers = details.getSubscriptionOfferDetails();
            if (offers == null || offers.isEmpty()) {
                markAllSubscriptionCardsUnavailable();
                return;
            }

            // Cache details so we can launch purchase later
            productDetailsMap.put(productId, details);

            boolean found1M = false, found3M = false, found6M = false, found1Y = false;

            for (ProductDetails.SubscriptionOfferDetails offer : offers) {

                String basePlanId = offer.getBasePlanId();
                if (basePlanId == null) continue;

                String uiKey;
                if (PLAN_1_MONTH.equals(basePlanId))       { uiKey = UI_1_MONTH; found1M = true; }
                else if (PLAN_3_MONTH.equals(basePlanId))  { uiKey = UI_3_MONTH; found3M = true; }
                else if (PLAN_6_MONTH.equals(basePlanId))  { uiKey = UI_6_MONTH; found6M = true; }
                else if (PLAN_1_YEAR.equals(basePlanId))   { uiKey = UI_1_YEAR;  found1Y = true; }
                else continue;

                // Prefer the plain base plan (offerId == null); otherwise keep first
                boolean hasPlain = false;
                if (offer.getOfferId() == null) {
                    // Always prefer the plain base plan
                    applySubOffer(uiKey, offer, productId);
                    hasPlain = true;
                }
                if (!hasPlain) {
                    // If we already have a plain offer stored, don't overwrite it
                    if (!offerTokens.containsKey(uiKey)) {
                        applySubOffer(uiKey, offer, productId);
                    }
                }
            }

            if (!found1M) markCardUnavailable(UI_1_MONTH);
            if (!found3M) markCardUnavailable(UI_3_MONTH);
            if (!found6M) markCardUnavailable(UI_6_MONTH);
            if (!found1Y) markCardUnavailable(UI_1_YEAR);

        } else {

            if (!LIFETIME.equals(productId)) return;

            ProductDetails.OneTimePurchaseOfferDetails offer = details.getOneTimePurchaseOfferDetails();
            if (offer == null) {
                markCardUnavailable(UI_LIFETIME);
                return;
            }

            productDetailsMap.put(productId, details);

            TextView priceLabel = priceLabels.get(UI_LIFETIME);
            if (priceLabel != null) {
                priceLabel.setText(offer.getFormattedPrice() + " (one time)");
            }

            Button buyButton = purchaseButtons.get(UI_LIFETIME);
            if (buyButton != null) {
                buyButton.setEnabled(true);
                buyButton.setAlpha(1f);
            }
        }
    }

    private void applySubOffer(String uiKey,
                               ProductDetails.SubscriptionOfferDetails offer,
                               String productId) {

        List<ProductDetails.PricingPhase> phases = offer.getPricingPhases().getPricingPhaseList();
        if (phases == null || phases.isEmpty()) {
            markCardUnavailable(uiKey);
            return;
        }

        // Last phase = the recurring price
        String formattedPrice = phases.get(phases.size() - 1).getFormattedPrice();

        // Store the offer token keyed by UI key so launchPurchase can find it.
        // Also store by productId (base plan) for reference if needed.
        offerTokens.put(uiKey, offer.getOfferToken());
        offerTokens.put(productId + "::" + uiKey, offer.getOfferToken());

        TextView priceLabel = priceLabels.get(uiKey);
        if (priceLabel != null) {
            priceLabel.setText(formattedPrice + " / plan period");
        }

        Button buyButton = purchaseButtons.get(uiKey);
        if (buyButton != null) {
            buyButton.setEnabled(true);
            buyButton.setAlpha(1f);
        }
    }

    // ================================================================
    // LAUNCH PURCHASE
    // ================================================================

    private void launchPurchase(String uiKey) {

        if (billingClient == null || !billingClient.isReady()) {
            toast("Connecting to Google Play... tap again in a moment.");
            connectBilling();
            return;
        }

        if (amar_t.getBoolean(KEY_LIFETIME, false)) {
            toast("You already have Lifetime Pro.");
            return;
        }

        boolean isLifetime = UI_LIFETIME.equals(uiKey);

        if (!isLifetime && amar_t.getBoolean(KEY_SUB, false)) {
            toast("You already have an active subscription. Opening subscription manager...");
            openManageSubscription();
            return;
        }

        doLaunchPurchase(uiKey);
    }

    private void doLaunchPurchase(String uiKey) {

        if (isFinishing()) return;

        long now = System.currentTimeMillis();
        if ((now - lastLaunchStartMs) < LAUNCH_COOLDOWN_MS) return;
        if (isLaunchingFlow && (now - launchLockTimeMs) < LAUNCH_LOCK_TIMEOUT_MS) return;

        boolean isLifetime = UI_LIFETIME.equals(uiKey);
        String productId = isLifetime ? LIFETIME : SUB_PRODUCT;

        ProductDetails details = productDetailsMap.get(productId);

        if (details == null) {
            toast("Product details loading. Please try again.");
            queryRealProductPrices();
            return;
        }

        BillingFlowParams.ProductDetailsParams.Builder productParamsBuilder =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details);

        // Subscriptions REQUIRE the offer token of the specific base plan
        if (!isLifetime) {
            String token = offerTokens.get(uiKey);
            if (token == null || token.isEmpty()) {
                toast("Plan not ready. Please try again.");
                queryRealProductPrices();
                return;
            }
            productParamsBuilder.setOfferToken(token);
        }

        List<BillingFlowParams.ProductDetailsParams> productParamsList = new ArrayList<>();
        productParamsList.add(productParamsBuilder.build());

        final BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(productParamsList)
                .build();

        isLaunchingFlow = true;
        launchLockTimeMs = System.currentTimeMillis();
        lastLaunchStartMs = launchLockTimeMs;
        setPurchaseButtonsEnabled(false);

        mainHandler.post(() -> {
            if (isFinishing() || billingClient == null) return;

            BillingResult result = billingClient.launchBillingFlow(MainActivity.this, flowParams);

            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                releaseLaunchLock();
                handleLaunchError(result.getResponseCode(), result.getDebugMessage());
            }
        });
    }

    private void handleLaunchError(int code, String message) {

        if (code == BillingClient.BillingResponseCode.SERVICE_DISCONNECTED) {
            toast("Google Play was disconnected. Reconnecting... tap again in a few seconds.");
            connectBilling();
            return;
        }

        if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            toast("Already owned. Restoring...");
            restorePastPurchases();
            return;
        }

        if (code == BillingClient.BillingResponseCode.DEVELOPER_ERROR) {
            if (isDuplicateMessage(message)) {
                toast("Please wait, the purchase screen is already opening.");
                return;
            }
            handleSetupFailure(code, message);
            toast("Billing configuration error (5). See the message on screen.");
            return;
        }

        toast("Could not open Google Play\nCode: " + code
                + ((message != null && !message.isEmpty()) ? ("\n" + message) : ""));
    }

    // ================================================================
    // PURCHASES UPDATED
    // ================================================================

    private final PurchasesUpdatedListener purchasesUpdatedListener =
            new PurchasesUpdatedListener() {

                @Override
                public void onPurchasesUpdated(@NonNull BillingResult result, List<Purchase> purchases) {

                    releaseLaunchLock();

                    int code = result.getResponseCode();

                    if (code == BillingClient.BillingResponseCode.OK) {
                        setStatus(null);
                        if (purchases != null) {
                            for (Purchase purchase : purchases) {
                                handlePurchase(purchase);
                            }
                        }
                        return;
                    }

                    if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
                        toast("Purchase cancelled.");
                        return;
                    }

                    if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
                        toast("Already owned. Restoring...");
                        restorePastPurchases();
                        return;
                    }

                    if (code == BillingClient.BillingResponseCode.SERVICE_DISCONNECTED) {
                        toast("Google Play disconnected.");
                        connectBilling();
                        return;
                    }

                    if (code == BillingClient.BillingResponseCode.DEVELOPER_ERROR) {
                        if (isDuplicateMessage(result.getDebugMessage())) {
                            toast("Please wait, the purchase is already in progress.");
                            return;
                        }
                        handleSetupFailure(code, result.getDebugMessage());
                        toast("Billing configuration error (5). See the message on screen.");
                        return;
                    }

                    toast("Purchase failed\nCode: " + code);
                }
            };

    // ================================================================
    // HANDLE PURCHASE
    // ================================================================

    private void handlePurchase(Purchase purchase) {

        if (purchase == null) return;

        int state = purchase.getPurchaseState();

        if (state == Purchase.PurchaseState.PENDING) {
            toast("Purchase pending. Pro will be activated after payment completes.");
            return;
        }

        if (state != Purchase.PurchaseState.PURCHASED) return;

        List<String> products = purchase.getProducts();
        if (products == null || products.isEmpty()) return;

        boolean isLifetime = products.contains(LIFETIME);
        boolean isSubscription = products.contains(SUB_PRODUCT);

        if (!isLifetime && !isSubscription) return;

        if (isLifetime) {
            amar_t.edit().putBoolean(KEY_LIFETIME, true).apply();
        } else {
            amar_t.edit()
                    .putBoolean(KEY_SUB, true)
                    .putLong(KEY_VERIFIED, System.currentTimeMillis())
                    .apply();
        }
        mainHandler.post(this::refreshProUi);

        if (!purchase.isAcknowledged()) {
            acknowledge(purchase, isLifetime);
        }
    }

    private void acknowledge(final Purchase purchase, final boolean isLifetime) {
        executeServiceRequest(() -> {
            if (billingClient == null || !billingClient.isReady()) return;

            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.getPurchaseToken())
                    .build();

            billingClient.acknowledgePurchase(params, result -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    toast(isLifetime
                            ? "Lifetime Pro activated!"
                            : "Pro subscription activated!");
                }
            });
        });
    }

    // ================================================================
    // RESTORE / VERIFY
    // ================================================================

    private void restorePastPurchases() {
        executeServiceRequest(this::doRestorePastPurchases);
    }

    private void doRestorePastPurchases() {

        if (billingClient == null || !billingClient.isReady()) return;

        QueryPurchasesParams subsParams = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build();

        billingClient.queryPurchasesAsync(subsParams, (subsResult, subsPurchases) -> {

            if (subsResult.getResponseCode() != BillingClient.BillingResponseCode.OK) return;

            final boolean subFound = hasActive(subsPurchases);
            if (subsPurchases != null) {
                for (Purchase p : subsPurchases) handlePurchase(p);
            }

            if (billingClient == null || !billingClient.isReady()) return;

            QueryPurchasesParams inappParams = QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build();

            billingClient.queryPurchasesAsync(inappParams, (inappResult, inappPurchases) -> {

                if (inappResult.getResponseCode() != BillingClient.BillingResponseCode.OK) return;

                boolean lifeFound = false;
                if (inappPurchases != null) {
                    for (Purchase p : inappPurchases) {
                        if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED
                                && p.getProducts().contains(LIFETIME)) {
                            lifeFound = true;
                        }
                        handlePurchase(p);
                    }
                }

                SharedPreferences.Editor ed = amar_t.edit();
                ed.putBoolean(KEY_SUB, subFound);
                ed.putBoolean(KEY_LIFETIME, lifeFound);
                if (subFound) ed.putLong(KEY_VERIFIED, System.currentTimeMillis());
                ed.apply();

                mainHandler.post(this::refreshProUi);
            });
        });
    }

    private boolean hasActive(List<Purchase> purchases) {
        if (purchases == null) return false;
        for (Purchase p : purchases) {
            if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) return true;
        }
        return false;
    }

    // ================================================================
    // SMALL HELPERS
    // ================================================================

    private void setStatus(final String message) {
        mainHandler.post(() -> {
            if (statusText == null) return;
            if (message == null || message.isEmpty()) {
                statusText.setVisibility(View.GONE);
            } else {
                statusText.setText(message);
                statusText.setVisibility(View.VISIBLE);
            }
        });
    }

    private boolean isDuplicateMessage(String message) {
        return message != null && message.toLowerCase().contains("duplicate");
    }

    private void releaseLaunchLock() {
        isLaunchingFlow = false;
        launchLockTimeMs = 0L;
        mainHandler.post(() -> {
            for (Map.Entry<String, Button> e : purchaseButtons.entrySet()) {
                Button b = e.getValue();
                String uiKey = e.getKey();
                if (b != null && isCardReady(uiKey)) {
                    b.setEnabled(true);
                    b.setAlpha(1f);
                }
            }
        });
    }

    private boolean isCardReady(String uiKey) {
        if (UI_LIFETIME.equals(uiKey)) {
            return productDetailsMap.containsKey(LIFETIME);
        }
        return productDetailsMap.containsKey(SUB_PRODUCT)
                && offerTokens.containsKey(uiKey);
    }

    private void setPurchaseButtonsEnabled(final boolean enabled) {
        mainHandler.post(() -> {
            for (Map.Entry<String, Button> e : purchaseButtons.entrySet()) {
                Button b = e.getValue();
                if (b != null) {
                    boolean ready = enabled ? isCardReady(e.getKey()) : false;
                    b.setEnabled(ready);
                    b.setAlpha(ready ? 1f : 0.5f);
                }
            }
        });
    }

    private void disablePurchaseButtons() {
        setPurchaseButtonsEnabled(false);
    }

    private void toast(final String message) {
        mainHandler.post(() ->
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show()
        );
    }

    // ================================================================
    // LIFECYCLE
    // ================================================================

    @Override
    protected void onResume() {
        super.onResume();

        releaseLaunchLock();
        refreshProUi();

        if (billingClient == null) return;

        if (billingClient.isReady()) {
            reconnectDelayMs = RECONNECT_START_DELAY_MS;
            queryRealProductPrices();
            restorePastPurchases();
        } else if (!isConnecting && !retryScheduled) {
            setupRetryCount = 0;
            connectBilling();
        }
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        pendingServiceRequests.clear();

        if (billingClient != null) {
            billingClient.endConnection();
            billingClient = null;
        }

        super.onDestroy();
    }
}
